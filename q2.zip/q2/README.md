# Question 2

This folder contains the code and resources for Question 2.

## How to run

```
python q2.py
```
